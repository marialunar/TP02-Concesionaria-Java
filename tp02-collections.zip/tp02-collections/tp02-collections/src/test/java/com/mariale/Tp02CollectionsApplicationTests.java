package com.mariale;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp02CollectionsApplicationTests {

	@Test
	void contextLoads() {
	}

}

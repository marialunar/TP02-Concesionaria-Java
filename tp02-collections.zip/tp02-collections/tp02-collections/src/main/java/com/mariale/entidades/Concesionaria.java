package com.mariale.entidades;

import java.util.Comparator;
import java.util.List;

public class Concesionaria implements IConcesionaria {

    @Override
    public void mostrarVehiculos(List<Vehiculo> vehiculos) {
        vehiculos.forEach(System.out::println);
        System.out.println("=============================");
    }

    @Override
    public Vehiculo obtenerMasCaro(List<Vehiculo> vehiculos) {
        return vehiculos
                .stream()
                .max(Comparator.comparing(Vehiculo::getPrecio))
                .get();

    }

    @Override
    public Vehiculo obtenerMasBarato(List<Vehiculo> vehiculos) {
        return vehiculos
                .stream()
                .min(Comparator.comparing(Vehiculo::getPrecio))
                .get();
    }

    @Override
    public void mostrarOrdenadosPorPrecioDesc(List<Vehiculo> vehiculos) {
        System.out.println("Vehículos ordenados por precio de mayor a menor:");
        vehiculos
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));
    }

    @Override
    public void buscarPorLetra(List<Vehiculo> vehiculos) {
        vehiculos
                .stream()
                .filter(v -> v.getModelo().toUpperCase().contains("Y"))
                .forEach(v -> System.out.println("Vehículo que contiene en el modelo la letra 'Y': "
                        + v.getMarca() + " " + v.getModelo() + " " + v.getPrecioFormateado()));
    }

    @Override
    public void mostrarOrdenNatural(List<Vehiculo> vehiculos) {
        System.out.println("=============================");
        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
        vehiculos
                .stream()
                .sorted()
                .forEach(System.out::println);
    }

}
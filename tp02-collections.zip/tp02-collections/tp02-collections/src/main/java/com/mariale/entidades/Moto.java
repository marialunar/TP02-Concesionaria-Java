package com.mariale.entidades;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Moto extends Vehiculo {
    private String cilindrada;

    public Moto(String marca, String modelo, double precio, String cilindrada) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }

    @Override
    public String toString() {
        return String.format("Marca: %s // Modelo: %s // Cilindrada: %s // Precio: %s",
                getMarca(), getModelo(), cilindrada, getPrecioFormateado());
    }

}

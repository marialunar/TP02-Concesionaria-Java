package com.mariale;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp02CollectionsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tp02CollectionsApplication.class, args);
	}

}

package com.mariale.entidades;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Auto extends Vehiculo {
    private int puertas;

    public Auto(String marca, String modelo, double precio, int puertas) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    @Override
    public String toString() {
        return String.format("Marca: %s // Modelo: %s // Puertas: %d // Precio: %s",
                getMarca(), getModelo(), puertas, getPrecioFormateado());
    }

}

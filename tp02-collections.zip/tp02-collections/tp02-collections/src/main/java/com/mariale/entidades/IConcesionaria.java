package com.mariale.entidades;

import java.util.List;

public interface IConcesionaria {

    void mostrarVehiculos(List<Vehiculo> vehiculos); //imprime todos los vehículos.

    Vehiculo obtenerMasCaro(List<Vehiculo> vehiculos); //devuelve el vehículo con mayor precio.

    Vehiculo obtenerMasBarato(List<Vehiculo> vehiculos); //devuelve el vehículo con menor precio.

    void buscarPorLetra(List<Vehiculo> vehiculos); //imprime vehículos cuyo modelo contiene la letra 'Y'.

    void mostrarOrdenadosPorPrecioDesc(List<Vehiculo> vehiculos); //ordena y muestra por precio descendente.

    void mostrarOrdenNatural(List<Vehiculo> vehiculos); //ordena y muestra usando el orden natural.

}

package com.mariale.entidades;

import java.text.DecimalFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public abstract class Vehiculo implements Comparable<Vehiculo> {
    private String marca;
    private String modelo;
    private double precio;

    // Formato para el precio con dos decimales y separador de miles.
    // Convierte un valor numérico en un texto con formato de precio.
    private static final DecimalFormat formatoprecio = new DecimalFormat("$#,##0.00");

    public String getPrecioFormateado() {
        return formatoprecio.format(precio);
    }

    // Implementacion de interfaz Comparable<Vehiculo>
    // El método compareTo() define el orden natural de los vehículos.
    @Override
    public int compareTo(Vehiculo v) {
        int comparaMarca = this.marca.compareTo(v.marca);// Comparo marca
        if (comparaMarca != 0)
            return comparaMarca; // si son diferentes devuelvo el resultado
        int comparaModelo = this.modelo.compareTo(v.modelo); // Si marca son iguales comparo modelo
        if (comparaModelo != 0)
            return comparaModelo; // Si marca y modelo son iguales comparo por precio
        return Double.compare(this.precio, v.precio);
    }

    @Override
    public abstract String toString();
}

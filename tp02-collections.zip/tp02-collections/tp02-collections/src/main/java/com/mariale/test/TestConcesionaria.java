package com.mariale.test;

import java.util.List;

import com.mariale.entidades.Auto;
import com.mariale.entidades.Concesionaria;
import com.mariale.entidades.IConcesionaria;
import com.mariale.entidades.Moto;
import com.mariale.entidades.Vehiculo;

public class TestConcesionaria {
    public static void main(String[] args) {

        IConcesionaria servicio = new Concesionaria();

        //Crea una lista inmutable.
        //No podemos agregar ni eliminar elementos, pero se pueden iterar, filtrar y ordenar con Streams.
        List<Vehiculo> vehiculos = List.of(
                new Auto("Peugeot", "206", 200000, 4),
                new Moto("Honda", "Titan", 60000, "125c"),
                new Auto("Peugeot", "208", 250000, 5),
                new Moto("Yamaha", "YBR", 80500.50, "160c"));

        servicio.mostrarVehiculos(vehiculos);

        Vehiculo masCaro = servicio.obtenerMasCaro(vehiculos);
        Vehiculo masBarato = servicio.obtenerMasBarato(vehiculos);

        System.out.println("Vehículo más caro: " + masCaro.getMarca() + " " + masCaro.getModelo());
        System.out.println("Vehículo más barato: " + masBarato.getMarca() + " " + masBarato.getModelo());

        servicio.buscarPorLetra(vehiculos);

        System.out.println("=============================");
        servicio.mostrarOrdenadosPorPrecioDesc(vehiculos);

        servicio.mostrarOrdenNatural(vehiculos);

    }
}
